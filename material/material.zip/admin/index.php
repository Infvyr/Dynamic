<?php
    require_once "../mainDbase/db";
    $link = db_connect();




    include_once "articles_admin.php";
?>
