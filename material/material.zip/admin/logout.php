<?php  
header('location: ../');