 <!-- Inceput footer -->
  <footer class="page-footer indigo darken-4">
      <div class="row">
        <div class="col l6 m6 s12" id="footer_col1">
            <h5 class="white-text">Biblioteca Publică s.Gribova</h5>
            <div class="divider"></div>
            <p class="grey-text text-lighten-4" style="font-size:1.2em;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium excepturi quod consectetur esse, quas debitis libero quam incidunt consequatur adipisci temporibus nam ducimus dignissimos facere repellat ipsa at maiores ab?</p>
        </div>

        <div class="col l6 m6 s12">
            <h5 class="white-text" style="padding-left:10px;">Meniu</h5>
            <div class="divider"></div>
          <ul id="footer_menu">
            <li><a class="clr" href="/material">Principală</a></li>
            <li><a class="clr" href="#!">Activități</a></li>
            <li><a class="clr" href="/material/catalogBibl" title="căutați cartea în baza de date" target="_blank">catalog</a></li>
            <li><a class="clr" href="#!">foto</a></li>
            <li><a class="clr" href="#!">video</a></li>
            <li><a class="clr" href="/material/categories/despre.php" title="vizualizați informația despre bibiliotecă">despre</a></li>
            <li><a class="clr" href="/material/categories/contacte.php">contacte</a></li>
          </ul>
        </div>
      </div> <!-- row -->

    <div class="footer-copyright indigo darken-2" style="border-top: 1px solid #fefefe;">
      <center>
      Creat de: <a class="amber-text text-lighten-3" href="mailto:vnovatchi@gmail.com">Novațchii Vasile</a>
      </center>
    </div>
  </footer>
  <!-- Sfirsit footer -->